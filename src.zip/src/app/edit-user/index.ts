// tslint:disable-next-line: eofline
export * from './edit-user.component';
