import { Directive, ElementRef } from '@angular/core';

@Directive({
  // tslint:disable-next-line: directive-selector
  selector: '[focusable]'
})
export class FocusableDirective {

  constructor(private host: ElementRef) { }

  // tslint:disable-next-line: use-lifecycle-interface
  ngAfterViewInit() {
    this.host.nativeElement.focus();
  }

}
