import { NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

import { fakeBackendProvider } from './_helpers';
import { AppComponent } from './app.component';
import { HomeComponent } from './home';
import { LoginComponent } from './login';
import { RegisterComponent } from './register';

import { AddUserComponent } from './add-user/add-user.component';
import { EditUserComponent } from './edit-user/edit-user.component';
import { ListUserComponent} from './list-user/list-user.component';
import { appRoutingModule } from './app.routing';
import { JwtInterceptor, ErrorInterceptor } from './_helpers';
import { AlertComponent } from './_components';
import { UserService } from './_services';
import { ViewModeDirective } from './edit-user/view-mode.directive';
import { FocusableDirective } from './focusable.directive';
import { CommonModule } from '@angular/common';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { AppMaterialModule } from './material.module';
import {FlexLayoutModule} from '@angular/flex-layout';




@NgModule({
    imports: [
      AppMaterialModule,
        BrowserModule,
        CommonModule,
        ReactiveFormsModule,
        HttpClientModule,
        appRoutingModule,
        BrowserAnimationsModule,
        FormsModule,
        FlexLayoutModule
        ],
    declarations: [AppComponent,
        HomeComponent,
        LoginComponent,
        RegisterComponent,
        // AboutComponent,
        ListUserComponent,
        AddUserComponent,
        EditUserComponent,
        ViewModeDirective,
        FocusableDirective,

        AlertComponent

    ],

        providers: [
            UserService,
            { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
            { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
            // provider used to create fake backend
            fakeBackendProvider
        ],

    bootstrap: [AppComponent],
    schemas: [
        CUSTOM_ELEMENTS_SCHEMA,
        NO_ERRORS_SCHEMA
      ]
})
export class AppModule { }
