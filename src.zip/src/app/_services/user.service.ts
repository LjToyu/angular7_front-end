import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {User} from '../model/user.modal';

@Injectable({ providedIn: 'root' })
export class UserService {
    constructor(private http: HttpClient) { }
  router: any;
    baseUrl = 'http://localhost:8080/user-portal/users';
  update(value: any) {
    throw new Error('Method not implemented.');
  }


    // getUsers() {
    //    return this.http.get<User[]>(this.baseUrl);
    //  }

    getAll() {
        return this.http.get<any[]>(`/users`);
    }

    register(user: any) {
        return this.http.post(`/users/register`, user);
    }

    delete(id: number) {
        return this.http.delete(`/users/`);
    }
    firstClick() {
        console.log('clicked');
      }


      getUserById(id: number) {
        return this.http.get<User>(this.baseUrl + '/' + id);
      }

      createUser(user: User) {
        return this.http.post(this.baseUrl, user);
      }

}
