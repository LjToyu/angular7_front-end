import { Component, OnInit } from '@angular/core';

import {UserService} from '../_services/user.service';
import {User} from '../model/user.modal';
import { first } from 'rxjs/operators';
import { AuthenticationService } from '../_services';
import { FormBuilder } from '@angular/forms';

@Component({templateUrl: 'list-user.component.html'})
export class ListUserComponent implements OnInit {

  users: User[];
  currentUser: any;
  router: any;
  displayedColumns: string[] = ['username', 'firstName', 'lastName'];
  dataSource: void;

  constructor(
    private formBuilder: FormBuilder,
    private authenticationService: AuthenticationService,
    private userService: UserService) { this.currentUser = this.authenticationService.currentUserValue; }

  ngOnInit() {
    this.dataSource = this.loadAllUsers();
}

deleteUser(id: number) {
    this.userService.delete(id)
        .pipe(first())
        .subscribe(() => this.loadAllUsers());
}


private loadAllUsers() {
    this.userService.getAll()
      .subscribe(users => this.users = users);
}
editUser() {

this.router.navigate(['edit-user'])
.subscribe(users => this.users = users);
}

addUser() {
    this.router.navigate(['add-user']);
  }
}




/* ngOnInit() {
    this.userService.getUsers()
      .subscribe( data => {
        this.users = data;
      });
  }

  deleteUser(user: User): void {
    this.userService.deleteUser(user.id)
      .subscribe( data => {
        this.users = this.users.filter(u => u !== user);
      })
  };

  editUser(user: User): void {
    localStorage.removeItem("editUserId");
    localStorage.setItem("editUserId", user.id.toString());
    this.router.navigate(['edit-user']);
  };*/


