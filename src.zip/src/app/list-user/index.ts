// tslint:disable-next-line: eofline
export * from './list-user.component';
