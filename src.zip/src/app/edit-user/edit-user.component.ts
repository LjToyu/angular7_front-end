import { AuthenticationService } from '../_services';
// tslint:disable-next-line: max-line-length
import { Component, OnInit } from '@angular/core';

import { FormArray, FormGroup, FormBuilder } from '@angular/forms';
import { Subject } from 'rxjs';

@Component({ templateUrl: 'edit-user.component.html' })

export class EditUserComponent implements OnInit {


  constructor(
      private formBuilder: FormBuilder
       ) {

        this.visible = false; // set toolbar visible to false
    }

     currentUser: any;
    router: any;
    userService: any;
    visible: boolean;

    editForm: FormGroup;
    value = '';
    host: any;

  editMode = new Subject();
  editMode$ = this.editMode.asObservable();

  mode: 'view' | 'edit' = 'view';


  ngOnInit() {
    this.editForm = this.formBuilder.group({


      username: '',
      firstName: '',
      lastName: '',
  });

  }
  toViewMode() {
    throw new Error('Method not implemented.');
  }


onSubmit() {
  console.log(this.editForm.value);
}



  }

