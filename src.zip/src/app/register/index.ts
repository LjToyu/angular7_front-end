// tslint:disable-next-line: eofline
export * from './register.component';
